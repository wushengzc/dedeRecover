DELETE FROM `#@__payment` WHERE `code` = 'yeepay';

DELETE FROM `#@__payment` WHERE `code` = 'alipay';

INSERT INTO `#@__payment` (`code`, `name`, `fee`, `description`, `rank`, `config`, `enabled`, `cod`, `online`)
VALUES ('alipay', '支付宝', '2', '支付宝网站(www.alipay.com) 是国内先进的网上支付平台。<br/>DedeCMS联合支付宝推出支付宝接口。<br/><a href=https://open.alipay.com/ target="_blank"><font color="red">立即在线申请</font></a>', 1, 'a:4:{s:6:"app_id";a:4:{s:5:"title";s:6:"应用ID";s:11:"description";s:0:"";s:4:"type";s:4:"text";s:5:"value";s:0:"";}s:12:"ability_name";a:5:{s:5:"title";s:8:"能力名称";s:11:"description";s:46:"请在支付宝创建应用后在能力列表添加手机网站支付";s:4:"type";s:6:"select";s:5:"iterm";s:18:"1:使用手机网站支付";s:5:"value";s:1:"1";}s:20:"merchant_private_key";a:4:{s:5:"title";s:12:"RSA2商户私钥";s:11:"description";s:0:"";s:4:"type";s:4:"text";s:5:"value";s:0:"";}s:17:"alipay_public_key";a:4:{s:5:"title";s:14:"RSA2支付宝公钥";s:11:"description";s:81:"对应APPID下的支付宝公钥查看地址https://openhome.alipay.com/platform/keyManage.htm";s:4:"type";s:4:"text";s:5:"value";s:0:"";}}', 1, 0, 1);

INSERT INTO `#@__sysconfig` VALUES('20221', 'cfg_fail_limit', '用户锁定，连续登录失败N次', '2', 'number', '5');

INSERT INTO `#@__sysconfig` VALUES('20222', 'cfg_lock_time', '用户锁定，锁定时间（秒）', '2', 'number', '3600');

