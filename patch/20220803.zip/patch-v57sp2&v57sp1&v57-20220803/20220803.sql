INSERT INTO `#@__sysconfig` VALUES('744', 'cfg_replace_total', '限制一篇文章关键词类型总数（当一篇文章关键词类型过多可以开启此功能，选此功能可能会影响性能，0不开启）', '7', 'number', '0');

INSERT INTO `#@__sysconfig` VALUES('744', 'cfg_replace_sort', '当一篇文章关键词类型过多，如何获取（随机:0 顺序:1）', '7', 'number', '1');

