<?php  if(!defined('DEDEINC')) exit('DedeCMS Error: Request Error!');
/**
 * ��֤С����
 *
 * @version        $Id: validate.helper.php 1 2010-07-05 11:43:09 $
 * @package        DedeCMS.Helpers
 * @founder        IT����ͼ, https://weibo.com/itprato
 * @author         DedeCMS�Ŷ�
 * @copyright      Copyright (c) 2007 - 2021, �Ϻ�׿׿����Ƽ����޹�˾ (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

//�����ʽ���
if ( ! function_exists('CheckEmail'))
{
    function CheckEmail($email)
    {
        if (!empty($email))
        {
            return preg_match('/^[a-z0-9]+([\+_\-\.]?[a-z0-9]+)*@([a-z0-9]+[\-]?[a-z0-9]+\.)+[a-z]{2,6}$/i', $email);
        }
        return FALSE;
    }
}

