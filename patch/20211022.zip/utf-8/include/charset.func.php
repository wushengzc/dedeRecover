<?php
if(!defined('DEDEINC')) exit('DedeCMS Error: Request Error!');
// ------------------------------------------------------------------------
// 字符编码转换的小助手
// 这里仅做一个映射
helper("charset");