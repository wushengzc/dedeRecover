<?php
/**
 * �ϴ���Ƶ
 *
 * @version        $Id: select_media_post_wangEditor.php 1 9:43 2010��7��8�� $
 * @package        DedeCMS.Dialog
 * @founder        IT����ͼ, https://weibo.com/itprato
 * @author         DedeCMS�Ŷ�
 * @copyright      Copyright (c) 2007 - 2021, �Ϻ�׿׿����Ƽ����޹�˾ (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");

$uptime = time();
$adminid = $cuserLogin->getUserID();

if(isset($upfile) && is_uploaded_file($upfile))
{
    $dpath = MyDate("ymd", $uptime);

    if(!in_array(strtolower(pathinfo($upfile_name, PATHINFO_EXTENSION)), explode("|", $cfg_mediatype), true)) {
        $data = array(
            'errno' => 1,
            'message' => "���ϴ����ļ���չ�����������б� [{$cfg_mediatype}]�������ϵͳ���õĲ�����"
        );
        exit(json_encode($data));
    }

    if(!preg_match('#audio|media|video#i', $upfile_type)) {
        $data = array(
            'errno' => 1,
            'message' => "���ϴ����ļ��������⣬�����ļ����ͣ�"
        );
        exit(json_encode($data));
    }
    
    $savePath = $cfg_other_medias."/".$dpath;

    $filename = "{$adminid}_".MyDate("His",$uptime).mt_rand(100,999);
    $fs = explode(".", $upfile_name);
    $filename = $filename.".".$fs[count($fs)-1];
    $filename = $savePath."/".$filename;
    if(!is_dir($cfg_basedir.$savePath))
    {
        MkdirAll($cfg_basedir.$savePath, 777);
        CloseFtp();
    }
    $fullfilename = $cfg_basedir.$filename;
    
    @move_uploaded_file($upfile, $fullfilename);

    $inquery = "INSERT INTO `#@__uploads`(arcid,title,url,mediatype,width,height,playtime,filesize,uptime,mid)
    VALUES ('0','$upfile_name','$filename','3','0','0','0','$upfile_size','$uptime','$adminid'); ";
    $dsql->ExecuteNoneQuery($inquery);
    $fid = $dsql->GetLastID();
    AddMyAddon($fid, $filename);
}

$data = array(
    'errno' => 0,
    'data' => array(
        'url' => $filename,
    )
);
exit(json_encode($data));