<?php   if(!defined('DEDEINC')) exit("DedeCMS Error: Request Error!");
/**
 * ģ�ͻ���
 *
 * @version        $Id: model.class.php 1 13:46 2010-12-1 $
 * @package        DedeCMS.Libraries
 * @founder        IT����ͼ, https://weibo.com/itprato
 * @author         DedeCMS�Ŷ�
 * @copyright      Copyright (c) 2007 - 2021, �Ϻ�׿׿����Ƽ����޹�˾ (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

class Model
{
    var $dsql;
    var $db;

    function __construct()
    {
        $this->Model();
    }

    // ��������
    function Model()
    {
        global $dsql;
        if ($GLOBALS['cfg_mysql_type'] == 'mysqli')
        {
            $this->dsql = $this->db = isset($dsql)? $dsql : new DedeSqli(FALSE);
        } else {
            $this->dsql = $this->db = isset($dsql)? $dsql : new DedeSql(FALSE);
        }

    }

    // �ͷ���Դ
    function __destruct()
    {
        $this->dsql->Close(TRUE);
    }
}
