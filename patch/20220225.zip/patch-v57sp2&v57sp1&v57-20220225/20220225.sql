UPDATE `#@__sysconfig` SET `info` = 'Html编辑器支持（wangEditor、ckeditor、fck）' WHERE `varname` = 'cfg_html_editor';

