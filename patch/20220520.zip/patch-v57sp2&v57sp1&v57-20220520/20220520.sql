ALTER TABLE `#@__arctype` ADD `typeenglishname` VARCHAR(255) NOT NULL default '';

ALTER TABLE `#@__arctype` ADD `typebigimg` VARCHAR(255) NOT NULL default '';

ALTER TABLE `#@__arctype` ADD `typesmallimg` VARCHAR(255) NOT NULL default '';

