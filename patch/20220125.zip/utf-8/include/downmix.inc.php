<?php   if(!defined('DEDEINC')) exit("DedeCMS Error: Request Error!");
/**
 * 防采集混淆字符串
 *
 * @version        $Id: downmix.inc.php 1 9:14 2010年7月6日 $
 * @package        DedeCMS.Libraries
 * @founder        IT柏拉图, https://weibo.com/itprato
 * @author         DedeCMS团队
 * @copyright      Copyright (c) 2007 - 2021, 上海卓卓网络科技有限公司 (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
// 引入小助手
// 本版本的文件暂时仅作一个映射,今后开发直接采用helper('downmix');进行调用
helper('downmix');