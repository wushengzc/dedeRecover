<?php
/**
 * �ĵ���־����
 *
 * @version        $Id: archives_log_list.php 1 8:48 2010��7��13�� $
 * @package        DedeCMS.Administrator
 * @founder        IT����ͼ, https://weibo.com/itprato
 * @author         DedeCMS�Ŷ�
 * @copyright      Copyright (c) 2007 - 2021, �Ϻ�׿׿����Ƽ����޹�˾ (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");
CheckPurview('sys_Log');
require_once(DEDEINC."/datalistcp.class.php");
require_once(DEDEINC."/common.func.php");
require_once(DEDEADMIN."/inc/inc_list_functions.php");
$sql = $where = "";

$sql = "SELECT * FROM `#@__archives_log_list` ORDER BY `id` DESC";

$dlist = new DataListCP();
$dlist->pageSize = 20;
$dlist->SetTemplate(DEDEADMIN."/templets/archives_log_list.htm");
$dlist->SetSource($sql);
$dlist->Display();